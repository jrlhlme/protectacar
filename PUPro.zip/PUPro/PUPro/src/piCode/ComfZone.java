package piCode;


public class ComfZone {
	
	public void checkZone(){
		
	}
	
	private boolean okDistance(double sensorData){
		return true; //placeholder
	}

}

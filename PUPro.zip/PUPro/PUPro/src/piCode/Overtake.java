package piCode;

public class Overtake {
	
	private double overtakeDistance;
	
	public void checkOvertake(){
		
	}
	
	private boolean okOvertake(double sensorData){
		return true;
	}
}

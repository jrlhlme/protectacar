package piCode;

public class AutoBeam {

	private double switchThreshold;

	public void checkBeam(){
		
	}
	
	public void checkTreshold(double sensorData){
		
	}
}

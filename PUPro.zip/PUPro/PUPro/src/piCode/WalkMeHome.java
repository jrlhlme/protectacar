package piCode;

public class WalkMeHome {
	private int onTime;
	
	public void setTimer (int newTimer){
		this.onTime = newTimer;
	}
	
	public void activateTimer(){
		
	}
}

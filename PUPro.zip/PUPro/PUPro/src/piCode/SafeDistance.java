package piCode;

public class SafeDistance {

	private int distance; //type not decided
	
	public void checkAhead(){
		
	}
	
	private boolean okDistance(){
		return true;
	}

}
